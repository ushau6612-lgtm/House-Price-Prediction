# House Price Prediction

## Synopsis
This project focuses on predicting the price of a house based on features such as location, house size, number of rooms/bedrooms, bathrooms, parking, house age, and distance to the city. Students analyze relationships between these features and house prices and build a regression model.

## Objectives
- Analyze house-related data.
- Identify factors affecting house prices.
- Visualize price patterns.
- Train a regression model.
- Predict house prices.
- Evaluate the prediction results.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- property_id
- location
- house_size_sqft
- bedrooms
- bathrooms
- house_age_years
- parking_spaces
- distance_to_city_km
- price

Target:
- price — predicted house price

## Data Preparation
- Loaded the dataset using Pandas.
- Checked for missing values.
- Filled missing numerical values with median values.
- Filled missing categorical values with the most frequent value.
- Standardized numerical features.
- One-hot encoded the location feature.
- Split the data into training and testing sets.

## Machine Learning Algorithm
Linear Regression is used as the regression model.

## Evaluation
The program calculates:
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score
- Predicted price for a new house
- Important factors based on regression coefficients

It also generates:
- `size_vs_price.png`
- `actual_vs_predicted.png`

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python house_price_prediction.py

## Dataset Note
The included house-price dataset is synthetic and intended for educational/classroom machine-learning practice. It does not contain real property records.
